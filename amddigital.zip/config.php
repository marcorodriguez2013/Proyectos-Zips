<?php

define('URLCSS', 'public/css');
define('URLJS', 'public/js');
define('URLCSSSYSTEM', 'public/css_system/');
define('URLJSSYSTEM', 'public/js_system/');
define('URLCOMPOSER', 'public/composer/vendor/');
define('URLFW', 'public/fw/');
define('URLIMG', 'public/img/');
define('URLINC', 'public/inc/');
define('URLINCFUNC', '/public/inc_func/');
define('URLPUBLIC', 'public/');
define('URLAUDIO', 'public/audio/');
define('URLVIDEO', 'public/video/');
define('URLDOC', 'public/documentos/');
define('LIBS', 'libs/');
define('MODELS', './models/');
define('MODELS_', '/models/');
define('CONTROLLERS', '/controllers/');
define('VIEWS', '/views/');
define('BS', 'bussineslogic');
define('ALGORITMO', 'sha512');
define('HASHKEY', 'kassandra@2015');
define('NOMBRE_SESSION', 'adifact');
date_default_timezone_set('America/lima');
setlocale(LC_TIME, "spanish");
define('fecha_mysql', date("Y-m-d"));
define('hora_mysql', date("H:i:s"));
define('fecha_hora_mysql', date("Y-m-d H:i:s"));
